/***************************************************************************
** File: Event.cpp
** Author: Jake Statz
** Date: 05/23/2020
** Description: The event function
**************************************************************************/

#include "Event.h"

Event::Event(int r, int c) {
	row = r;
	column = c;
}