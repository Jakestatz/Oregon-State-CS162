#include <iostream>
#include <ftream>
#include <ccstdlib>
#include "student_db.h"

using namespace std;

int main(){
  student* array = create_student_db(int); 
  get_student_db_info(student *, int, fstream &); 
  delete_student_db_info(student *);
}
