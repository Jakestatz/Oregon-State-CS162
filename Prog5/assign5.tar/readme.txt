Jake Statz
933-525-590

This program allows th euser to input as many numbers as they would like and sorts them in ascending and descending order depending on what the user inputs. The program will also tell the user the number of prime number in the list.

I completed both extra credits of using template classes for both signed and unsigned ints, and the descending option of sorting.

Use the make file to compile and ./Linked to run.
